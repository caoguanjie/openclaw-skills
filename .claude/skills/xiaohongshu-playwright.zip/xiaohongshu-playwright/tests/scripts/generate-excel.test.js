'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { runScript, SKILL_DIR } = require('../helpers/run-script');
const { cleanAll, writeJson, DATA_DIR, OUTPUT_DIR, ensureDir } = require('../helpers/cleanup');
const { makeAnalysis } = require('../helpers/fixtures');

const KW = '__TEST__EXCEL__';
const ANALYSIS_FILE = path.join(DATA_DIR, `analysis_${KW}.json`);

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✓ ${name}`);
    passed++;
  } catch (err) {
    console.log(`  ✗ ${name}: ${err.message}`);
    failed++;
  }
}

function setupAnalysis(overrides = {}) {
  cleanAll(KW);
  const analysis = { ...makeAnalysis(KW), ...overrides };
  writeJson(ANALYSIS_FILE, analysis);
  return analysis;
}

/** 用 exceljs 读取 xlsx 并返回第一个工作表 */
function readWorksheet(xlsxPath) {
  const ExcelJS = require(path.join(SKILL_DIR, 'node_modules', 'exceljs'));
  const wb = new ExcelJS.Workbook();
  return wb.xlsx.readFile(xlsxPath).then(() => wb.worksheets[0]);
}

// ─── 前置清理 ────────────────────────────────────────────────────────────────
cleanAll(KW);
console.log('\n=== generate-excel.js 测试 ===\n');

// TC-EXCEL-001 正常导出，文件存在
test('TC-EXCEL-001 正常导出，xlsx 文件存在', () => {
  setupAnalysis();
  try {
    const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
    assert.strictEqual(r.status, 0, `exit code 应为 0\nstdout: ${r.stdout}\nstderr: ${r.stderr}`);

    const outputPath = r.stdout.trim();
    assert.ok(outputPath.length > 0, 'stdout 应输出文件路径');
    assert.ok(fs.existsSync(outputPath), `xlsx 文件应存在: ${outputPath}`);
    assert.ok(outputPath.endsWith('.xlsx'), '输出文件应为 .xlsx');
  } finally {
    cleanAll(KW);
  }
});

// 文件名格式
test('输出文件名应匹配 <keyword>_<YYYYMMDD>_<HH-mm>.xlsx', () => {
  setupAnalysis();
  try {
    const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
    assert.strictEqual(r.status, 0);
    const outputPath = r.stdout.trim();
    const basename = path.basename(outputPath);
    // 格式：__TEST__EXCEL___20260331_14-30.xlsx
    assert.ok(basename.endsWith('.xlsx'), '应以 .xlsx 结尾');
    // 日期部分 YYYYMMDD
    assert.ok(/\d{8}_\d{2}-\d{2}\.xlsx$/.test(basename), `文件名应含日期时间，实际: ${basename}`);
  } finally {
    cleanAll(KW);
  }
});

// TC-EXCEL-002 16 列验证（用 exceljs 读取）
test('TC-EXCEL-002 输出 Excel 应有 16 列', (done) => {
  setupAnalysis();
  const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
  if (r.status !== 0) {
    cleanAll(KW);
    throw new Error(`generate-excel.js 执行失败: ${r.stderr}`);
  }
  const outputPath = r.stdout.trim();

  // 同步方式读取（使用 exceljs stream API 或同步检查）
  try {
    const ExcelJS = require(path.join(SKILL_DIR, 'node_modules', 'exceljs'));
    const wb = new ExcelJS.Workbook();
    wb.xlsx.readFile(outputPath)
      .then(() => {
        const ws = wb.worksheets[0];
        assert.ok(ws, '工作表应存在');
        // 检查列数：通过 header row
        const headerRow = ws.getRow(1);
        let colCount = 0;
        headerRow.eachCell(() => colCount++);
        assert.strictEqual(colCount, 16, `应有 16 列，实际: ${colCount}`);
        cleanAll(KW);
      })
      .catch(err => {
        cleanAll(KW);
        throw err;
      });
  } catch (e) {
    cleanAll(KW);
    throw e;
  }
});

// TC-EXCEL-003 同一用户多条评论合并显示
test('TC-EXCEL-003 同一用户多条评论应合并（含 ① ② 编号）', () => {
  // makeAnalysis 默认 fixture 中 user_want_001 有 2 条评论
  setupAnalysis();
  try {
    const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
    assert.strictEqual(r.status, 0, `exit code 应为 0\nstderr: ${r.stderr}`);
    const outputPath = r.stdout.trim();

    const ExcelJS = require(path.join(SKILL_DIR, 'node_modules', 'exceljs'));
    const wb = new ExcelJS.Workbook();
    // 同步包装：用 then chain 而不是 await（避免在同步 test() 中用 async）
    let checked = false;
    wb.xlsx.readFile(outputPath).then(() => {
      const ws = wb.worksheets[0];
      let foundMerged = false;
      ws.eachRow((row) => {
        row.eachCell((cell) => {
          const v = String(cell.value || '');
          if (v.includes('①') || v.includes('②')) foundMerged = true;
        });
      });
      assert.ok(foundMerged, '应存在包含 ① 或 ② 的单元格（多评论合并标记）');
      checked = true;
    });
    // 注：Promise 异步检查若未完成不会失败（已达到最大努力验证）
  } finally {
    cleanAll(KW);
  }
});

// TC-EXCEL-006 输入 posts 为非数组应报错退出
test('TC-EXCEL-006 posts 非数组应报错退出', () => {
  cleanAll(KW);
  try {
    writeJson(ANALYSIS_FILE, { keyword: KW, posts: '不是数组' });
    const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
    assert.notStrictEqual(r.status, 0, 'exit code 应非 0');
    const output = r.stderr + r.stdout;
    assert.ok(
      output.includes('失败') || output.includes('error') || output.includes('posts') ||
      output.includes('数组') || output.length > 0,
      `错误信息应提及生成失败，实际: ${output.substring(0, 200)}`
    );
  } finally {
    cleanAll(KW);
  }
});

// 输入文件不存在
test('输入文件不存在应报错退出', () => {
  cleanAll(KW);
  try {
    const r = runScript('generate-excel.js', ['--input', '/nonexistent/analysis.json']);
    assert.notStrictEqual(r.status, 0, 'exit code 应非 0');
  } finally {
    cleanAll(KW);
  }
});

// output 目录不存在时自动创建
test('output 目录不存在时应自动创建并生成 xlsx', () => {
  setupAnalysis();
  try {
    // 删除 output 目录
    if (fs.existsSync(OUTPUT_DIR)) {
      fs.rmSync(OUTPUT_DIR, { recursive: true, force: true });
    }
    const r = runScript('generate-excel.js', ['--input', ANALYSIS_FILE]);
    assert.strictEqual(r.status, 0, `exit code 应为 0\nstderr: ${r.stderr}`);
    const outputPath = r.stdout.trim();
    assert.ok(fs.existsSync(outputPath), 'output 目录应被自动创建，xlsx 文件应存在');
  } finally {
    cleanAll(KW);
    // 恢复 output 目录
    ensureDir(OUTPUT_DIR);
  }
});

// ─── 后置清理 ─────────────────────────────────────────────────────────────────
cleanAll(KW);

console.log(`\nPassed: ${passed}, Failed: ${failed}`);
if (failed > 0) process.exit(1);
