#!/usr/bin/env node

const fs = require("fs");
const path = require("path");

function parseArgs() {
  const args = process.argv.slice(2);
  const opts = {
    keyword: "",
    json: "",
    jsonFile: "",
    output: "",
  };

  for (let i = 0; i < args.length; i++) {
    if (args[i] === "--keyword") opts.keyword = args[++i] || "";
    else if (args[i] === "--json") opts.json = args[++i] || "";
    else if (args[i] === "--json-file") opts.jsonFile = args[++i] || "";
    else if (args[i] === "--output") opts.output = args[++i] || "";
  }

  if (!opts.keyword) {
    throw new Error("--keyword 为必填参数");
  }

  return opts;
}

function sanitizeKeywordForFilename(keyword) {
  return String(keyword || "keyword")
    .replace(/[\\/:*?"<>|\s]+/g, "_")
    .replace(/^_+|_+$/g, "") || "keyword";
}

function uniqueList(values) {
  return [...new Set((values || []).filter(Boolean))];
}

function normalizeStringArray(values, label) {
  if (!Array.isArray(values)) {
    throw new Error(`${label} 必须为数组`);
  }
  return uniqueList(
    values
      .map((value) => String(value || "").trim())
      .filter(Boolean)
  );
}

function validateTaskSpec(rawSpec, keyword) {
  const spec = {
    keyword: String(rawSpec.keyword || keyword || "").trim(),
    post_relevance: {
      include: normalizeStringArray(rawSpec.post_relevance?.include || [], "post_relevance.include"),
      exclude: normalizeStringArray(rawSpec.post_relevance?.exclude || [], "post_relevance.exclude"),
    },
    comment_filter: {
      include: normalizeStringArray(rawSpec.comment_filter?.include || [], "comment_filter.include"),
      exclude: normalizeStringArray(rawSpec.comment_filter?.exclude || [], "comment_filter.exclude"),
    },
    semantic_focus: String(rawSpec.semantic_focus || "").trim(),
  };

  if (!spec.keyword) {
    throw new Error("task spec.keyword 不能为空");
  }

  return spec;
}

function buildDefaultOutput(keyword) {
  const dir = path.join(__dirname, "..", "data", "task-specs");
  const stamp = new Date().toISOString().replace(/[:]/g, "-").replace(/\..+/, "");
  return path.join(dir, `${stamp}_${sanitizeKeywordForFilename(keyword)}.json`);
}

function readStdin() {
  return new Promise((resolve, reject) => {
    // 检查是否有 stdin 输入
    if (process.stdin.isTTY) {
      resolve(null);
      return;
    }

    let data = "";
    process.stdin.setEncoding("utf-8");
    process.stdin.on("data", (chunk) => {
      data += chunk;
    });
    process.stdin.on("end", () => {
      resolve(data.trim() || null);
    });
    process.stdin.on("error", reject);
  });
}

async function main() {
  const opts = parseArgs();

  // 优先级：--json-file > stdin > --json
  let jsonString;
  if (opts.jsonFile) {
    // 从文件读取（明确指定 UTF-8 编码）
    jsonString = fs.readFileSync(path.resolve(opts.jsonFile), "utf-8");
  } else {
    // 回退到 stdin 或 --json 参数
    const stdinData = await readStdin();
    jsonString = stdinData || opts.json;
  }

  if (!jsonString) {
    throw new Error("必须通过 --json-file、stdin 或 --json 参数提供 JSON 数据");
  }

  const rawSpec = JSON.parse(jsonString);
  const spec = validateTaskSpec(rawSpec, opts.keyword);
  const outputPath = opts.output ? path.resolve(opts.output) : buildDefaultOutput(spec.keyword);

  const outputDir = path.dirname(outputPath);
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }

  fs.writeFileSync(outputPath, JSON.stringify(spec, null, 2), "utf-8");
  console.log(outputPath);

  // 成功后删除临时文件（如果是 .temp- 开头）
  if (opts.jsonFile && path.basename(opts.jsonFile).startsWith('.temp-')) {
    try {
      fs.unlinkSync(path.resolve(opts.jsonFile));
    } catch (err) {
      // 忽略删除失败
    }
  }
}

main().catch((err) => {
  console.error("错误:", err.message);
  process.exit(1);
});
